---
layout: default
title: El culo de Verónica
---

La parte de la historia que se sabe es la siguiente: Una joven, en lo que parece estado de embriaguez o drogada, aparece en un vídeo siendo violada por un matrimonio que resultan ser vecinos suyos. Primero graba el marido y luego graba la mujer. El vídeo aparece unas pocas horas en un popular pornotube hasta que lo eliminan y desaparece de la faz de Internet. El vídeo es de 60 minutos de duración.

<img src="http://solido.greenshines.com/violada.jpg" alt="violada" width="1280" height="720" class="alignnone size-full wp-image-65850" />

¿Es el vídeo real? ¿es una simulación todo lo que pasa allí? ni idea. La cosa es que el vídeo ha aparecido de nuevo donde tenía que aparecer: en la web de los videos prohibidos, la web que recopila todo lo que está prohibido o censurado en los pornotubes.

Puedes bajarlo de aquí. En el siguiente enlace he dejado unas instrucciones muy simples para entrar a la web que recopila todos estos vídeos.

Entrar a bajarse el vídeos es sencillo, solo hay que seguir estos pasos</p>

<span style="font-size: 110%; font-weight: bold"><b>PASO 1:</b></span><br>

El vídeo está alojado en PunishTube, PunishTube es una web gratuita que aloja todos estos vídeos que nadie se atreve a alojar por miedo a que les cierren el servidor.

Para bajar el vídeo y todos los otros de la web entra en la web usando <a href="http://php.greenshines.com/out/punishtube">este enlace</a> y haz click donde pone "REGISTRO GRATUITO". Si al entrar te sale en ingles, fíjate que arriba a la derecha puedes cambiar el idioma y ponerla en español.

<img src="http://solido.greenshines.com/Screenshot-2015-04-26-00.14.27.png">

<span style="font-size: 110%; font-weight: bold"><b>PASO 2:</b></span>

Tras hacer click aparece un formulario que tienes que rellenar como lo rellenarías en cualquier redsocial. Si te fijas al final del formulario avisan de que la web es gratis.

<img src="http://solido.greenshines.com/Screenshot-2015-04-26-00.10.30.png">

<span style="font-size: 110%; font-weight: bold"><b>PASO 3:</b></span><br>

Tras este formulario aparecera un segundo formulario para que demuestres que eres mayor de edad introduciendo tu tarjeta de crédito, esto es algo cada vez mas normal en las webs para adultos y sobre todo si contienen material tan fuerte.

Fijate que ellos mismos dicen y yo te repito porque llevo tiempo registrado que: <b>la web es gratis y no cobran absolutamente nada</b> en tu tarjeta. La web es gratis y hasta el día de hoy esa es la forma legal en Estados Unidos para comprobar en este tipo de webs que eres mayor de edad. Este es el formulario.</P>

<img src="http://solido.greenshines.com/Screenshot-2015-04-26-00.14.57.png">

<span style="font-size: 110%; font-weight: bold"><b>PASO 4:</b></span><br>
Una vez que hayas rellenado el formulario ya estás dentro para siempre, podrás descargar y ver todo lo que quieras sin límites de PunishTube.

<center><a style="font-size: 110%; font-weight: bold" href="http://php.greenshines.com/out/punishtube">Entrar a Punish Tube</a>.</center>

PUNISHTUBE está 100% certificada por Greenshines.