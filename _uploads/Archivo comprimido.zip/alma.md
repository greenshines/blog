---
layout: default
title: Alma
---


Alma es probablemente hoy la mujer más buscada de Internet. Una sola foto y la posibilidad de que existan más ha disparado la curiosidad de miles de hombres.

Alma envió decenas de fotos y vídeos a su profesor de la universidad durante los 6 meses que duró la relación que mantuvo en secreto con él, hasta que uno de los alumnos de la facultad descubrió en un ordenador todas las fotos. Alma había dejado abierta una sesión de Dropbox con todas las fotos dentro.

<img src="http://solido.greenshines.com/ALMA.jpg">

Alguien ha subido todas las fotos y los vídeos a Free Passport un servicio de alojamiento de ficheros del que nunca borran nada. Esto es muy importante porque por lo general en otros servicios de alojamiento este tipo de cosas no duran ni un par de horas, Free Passport es famoso por aguantar todo tipo de amenazas y no borran nada de nada. 

Al lio, para bajar todo esto solo tienes que abrirte una cuenta en Free Passport, es gratis y fácil. Cuando te hayas abierto la cuenta puedes bajar el ZIP con los vídeos y fotos del tema que nos ocupa de este enlace: 

<a href="http://php.greenshines.com/out/almafotosyvideos">http://php.greenshines.com/out/almafotosyvideos</a>

He escrito unas instrucciones muy sencillas sobre como abrir una cuenta en Free Passport, porque a pesar de que es fácil está en inglés y puede que haya quien no se entere.

<h2>Cómo abrir una cuenta Free Passport</h2>

Free Passport es una web de alojamiento porno de así de simple. Lo que la diferencia de las demás es que no borran nada, tienen sus servidores alojados en no se que país de Europa del este y cuando hay un vídeo de esos que eliminan de todos los pornotubes y son imposibles de encontrar, puedes dar por seguro que alguien lo ha subido a Free Passport y que además allí se va a quedar para los restos.

Registrarse en Free Passport es muy sencillo, se hace igual que lo harías en cualquier red social: metes tu nombre (no tiene porque ser el de verdad) eliges un usuario y un password y listo. Aun así como la web está en inglés se me ha ocurrido hacer unas instrucciones muy simples para que puedas registrarte.

<hr>

<div class="row">

<div class="six columns">
<h2>PASO 1</h2>

Free Passport es una web gratuita que aloja todos esos vídeos y fotos que nadie se atreve a alojar por miedo a que les cierren el servidor. 

Para abrirte una cuenta en Free Passport pase por aquí caballero —> <a href="http://php.greenshines.com/out/freepassport">Registro a Free Passport</a>

Tras hacer click aparecerá un formulario que tienes que rellenar como lo rellenarías en cualquier red social. Si te fijas en el formulario avisan de que la web es gratis.

<img width="500" src="http://solido.greenshines.com/Screen-Shot-2016-11-01-at-2.41.22-AM.png">

</div>

<div class="six columns">
<h2>PASO 2</h2>

Tras este formulario aparecerá un segundo formulario para que demuestres que eres mayor de edad introduciendo tu tarjeta de crédito, esto es algo cada vez mas normal en las webs para adultos gratis con contenido pornográfico. <strong>NO COBRAN NADA EN TU TARJETA POR ABRIRTE LA CUENTA</strong>.

Fíjate que ellos mismos dicen, y yo te repito porque llevo tiempo registrado, que la web es gratis y no cobran absolutamente nada en tu tarjeta. La web es gratis y hasta el día de hoy esa es la forma legal para comprobar en este tipo de webs que eres mayor de edad. Este es el formulario.

<img width="500" src="http://solido.greenshines.com/Screen-Shot-2016-11-01-at-2.42.22-AM.png">
</div>
</div>

Una vez que hayas rellenado el formulario ya estás dentro para siempre, podrás descargar y ver todo lo que quieras sin límites de Free Passport.

<strong>ENLACE:</strong> <a href="http://php.greenshines.com/out/freepassport">ABRIR UNA CUENTA EN FREE PASSPORT</a>