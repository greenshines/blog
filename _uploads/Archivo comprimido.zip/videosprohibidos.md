---
layout: default
title: Videos prohibidos de Internet
---

Existe en Internet una web que recopila todos esos vídeos que busca la gente. El tipo de vídeos que los pornotubes normales no se atreven a poner y que por lo tanto son siempre los más buscados.

<img src="http://greenshines.com/wp-content/uploads/2015/02/Screenshot-2015-02-16-04.57.031.png" alt="Screenshot 2015-02-16 04.57.03" width="1000" height="612" class="alignnone size-full wp-image-65741" />

La web se llama <a href="http://crtracklink.com/go/cbUt2_bv8gt/DEFAULT">Punish Tube</a> y a pesar de que puede parecer una web de vídeos gratis al uso, no lo es. No lo es primero porque sus vídeos están todos en HD y se han preocupado de mantener un acalidad fuera de lo común, pero no es una web de vídeos porno gratis al uso sobre todo porque lo que contiene la web es como he dicho antes lo que nadie se atreve a publicar.

La web es totalmente gratuita, pero piden que tengas una tarjeta de crédito para comprobar que eres mayor de edad. No te cobran nada y te lo dicen hasta en dos ocasiones.

<a href="http://crtracklink.com/go/cbUt2_bv8gt/DEFAULT"><img src="http://greenshines.com/wp-content/uploads/2015/02/Screenshot-2015-02-16-05.05.04.png" alt="Screenshot 2015-02-16 05.05.04" width="866" height="376" class="alignnone size-full wp-image-65742" /></a>

<img src="http://greenshines.com/wp-content/uploads/2015/02/Screenshot-2015-02-16-05.04.29.png" alt="Screenshot 2015-02-16 05.04.29" width="1446" height="358" class="alignnone size-full wp-image-65743" />

Es una practica que cada vez es más común en Estados Unidos que pidan una tarjeta de crédito para verificar la edad de los usuarios de webs con contenido especialmente fuerte.

Si te gustan este tipo de vídeos, no lo dudes, esta es tu web. Si no te habías planteando nunca buscar este tipo de webs o si ni siquiera sabías que existian, no vas a dar crédito a tus ojos de lo que allí se puede ver.

La Web se llama Punish Tube, y puedes entrar usando este enlace: <a href="http://crtracklink.com/go/cbUt2_bv8gt/DEFAULT">Punish Tube</a>.

La web esta 100% certificada por Greenshines. Ah, si al entrar te sale en ingles, fíjate que arriba a la derecha puedes cambiar la banderita y ponerla en español.