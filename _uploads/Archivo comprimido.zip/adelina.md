---
layout: default
title: Adelina
---


<img src="http://greenshines.com/wp-content/uploads/2016/02/adelina-900x478.jpg" alt="" width="900" height="478" class="" />
	
<p>Adelina, es una mujer portuguesa de unos ¿35? años, puede que más. Sus vídeos aparecieron en Internet hace meses y corrieron como la pólvora por muchos foros, no solo porque Adelina estaba bastante buena sino porque días más tarde se descubrió que era la mujer de un decano de la universidad Lisboa, y lo que es casi peor, el que aparece follándose a Adelina en el vídeo un estudiante de la misma universidad en la que su marido es decano.</p>

<p>Cuando se descubrió todo el pastel, en menos de 24 horas los vídeos se esfumaron de Internet, era prácticamente imposible encontrarlo. Una vez más, uno de esos vídeos que todo el mundo quiere ver desaparece como por arte de magia de Internet. Un drama.</p>

<p>Pero aquí, en este punto de la historia es donde entra mi web favorita para este tipo de cosas. <a href="http://greenshines.com/out/dapink">DaPink</a>, dapink es la hermana menor de PunishTube una web de la que ya he hablado alguna vez. DaPink es una web especializada en este tipo de historias con vídeos desaparecidos de por medio.

A pesar de que es una web americana, sus servidores están en vete a saber que país y se encuentra a salvo de demandas y amenazas. Pueden mantener online cualquier cosa sin que nadie pueda obligarlos a borrar nada, así que son el sitio donde suelen terminar apareciendo todas las fotos y vídeos, y en definitiva tesoros, que desaparecen de Internet.</p>

<p>Soy Miembro de DaPink desde hace tiempo, y hace un rato me he llevado una sorpresa increíble al ver allí 3 meses después de que todo aquello pasase, no solo el vídeo que yo conocía sino todas las fotos y más vídeos de Adelina y el estudiante. Nada más verlo he saltado a mi ordenador y me he puesto a escribir este post. Escúchame bien, esto que estas a punto de ver es algo fuera de lo normal. Si hasta hoy no sabías nada de Adelina sus fotos, pero sobre todo sus 5 vídeos, van a cambiar tu visión del mundo y del universo.</p>

<p>Entrar en <a href="http://greenshines.com/out/dapink">DaPink</a> y bajarte el vídeo no tiene ningún misterio, es casi como registrarte a una redsocial cualquiera, pero aquí te dejo unas mini instrucciones porque la web está en Ingles y puede que haya alguien a quien pueda ayudarle estos 3 ó 4 pasos que voy a dejar aquí.</p>

<p><strong><strong>INSTRUCCIONES PARA BAJAR EL PORNO DE DAPINK</strong></strong></p>

<h2>Paso 1:</h2> 

Lo primero que tienes que hacer es por supuesto entrar a la web.
<br><strong>enlace:</strong> <a href="http://greenshines.com/out/dapink">ENTRAR A DA PINK</a></p>

<p>Al entrar en la web verás que arriba a la derecha hay un botón que dice CREATE MY FREE ACCOUNT (crear mi cuenta gratis) haz click ahí y en ningún otro sitio.</p>

<img src="http://greenshines.com/wp-content/uploads/2016/02/Captura-de-pantalla-2017-03-13-16.57.53.png" alt="" width="670" height="210" class="" />

<h2>Paso 2:</h2> Cuando hayas hecho click te aparecerá un formulario como este para que elijas tu nombre de usuario y contraseña. También te pide tu nombre pero no hace falta que pongas el verdadero claro.</p>

<p><img style="margin-left:auto; margin-right:auto;max-width:60%; height:auto" src="http://solido.greenshines.com/Screenshot-2015-04-26-04.28.26.png"></p>

<h2>Paso 3</strong></h2>

<p>Tras este formulario aparecerá un segundo formulario para que demuestres que eres mayor de edad introduciendo tu tarjeta de crédito, esto es algo cada vez mas normal en las webs para adultos.</p>

<p>Fíjate que ellos mismos dicen y yo te repito porque llevo tiempo registrado que: <b>la web es gratis y no cobran absolutamente nada</b> en tu tarjeta. La web es totálmente gratis y hasta el día de hoy esa es la forma legal en Estados Unidos para comprobar en este tipo de webs que eres mayor de edad y evitar que entren menores a la página. Este es el formulario que verás.</p>

<p><img style="margin-left:auto; margin-right:auto;max-width:60%; height:auto" src="http://solido.greenshines.com/Screenshot-2015-04-26-03.29.04.png"></p>

<p>Y esto es todo, verificas tu edad y estas dentro de una web clónica de otra que cuesta mucho dinero y que todos conocemos. Imagino que ya no te vere en dos o tres días, los vas a pasar descargando videos.
<br><br></p>

ENLACE: <a href="http://frtya.com/go/pLhl_bv8gt/adelina">Entrar en DaPink y Descargar el vídeo</a>