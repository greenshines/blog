---
layout: default
title: Greenshines

---

# Mensaje enviado por una enfermera del hospital de Ceuta: 

"Buenos días . Os voy a contar que me acaban de llamar de la dirección para ir a urgencias a reforzar que ha habido una avalancha de negros , aprox 400 que han saltado la valla. Pero a los que estamos atendiendo no son negros , son guardias civiles bastante jóvenes a los que los cabrones de los negros les han echado cal viva . Todos con los brazos , ojos y demás miembros quemados . A ver si esto sale en las noticias. Que pena . Uno llorando diciendo que él no se podía imaginar lo q les ha pasado . En fin .que estoy indignada"