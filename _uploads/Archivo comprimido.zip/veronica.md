---
layout: default
title: El culo de Verónica
---

Verónica, era una de esas chicas que guardan fotos de ellas mismas desnudas repartidas entre su teléfono móvil y algunas carpetas sueltas en su ordenador. En principio nada fuera de lo normal todas las chicas, absolutamente todas, tienen fotos y vídeos de ellas desnudas y un porcenatje enorme de esas fotos de una manera o de otra siempre terminan en Internet. Pero esta historia no es como todas las demás, esta historia es especial porque Veronica era española y además tenía uno de los mejores culos que habíamos visto en todos estos años de Internet, no exagero, algo increible. Se podría haber hecho millonaria con ese culo.

Las leyendas sobre como acabaron sus fotos en Internet son muchas, desde que simplemente las subio ella misma a una web hasta que se las robaron de su teléfono móvil en la universidad, da igual. Da igual más que nada porque nunca sabremos la verdad, así que cada cual se debe creer la historia que más le guste.

<img src="http://solido.greenshines.com/veronica-el-mejor-culo-de-internet.jpg">

Lo que todos sabemos por desgracia, aquí no hay leyenda, es que de la noche a la mañana el mejor culo de Internet se esfumó. Las fotos desapareciéron de todas las webs, de los vídeos no se volvió a saber nunca más. Una tragedia, hablo en serio, es una tragedia que unas fotos como esas y sobre todo el segundo vídeo hubiésen desaparecido para siempre.

A veces pasa eso, si se pone un poco de empeño y se tiene dinero y paciencia se puede hacer desaparecer cualquier cosa de Internet y Verónica parece que tenía bastante de todo eso. Todo desapareció de Internet como por arte de magia.

Pero aquí, en este punto de la historia es donde entra mi web favorita para este tipo de cosas. <a href="http://greenshines.com/out/dapink">DaPink</a>, dapink es la hermana menor de PunishTube una web de la que ya he hablado alguna vez. DaPink es una web especializada en este tipo de historias con teens de por medio. A pesar de que es una web americana, sus servidores están en vete a saber que país y se encuentra a salvo de demandas y amenazas. Pueden mantener online cualquier cosa sin que nadie pueda obligarlos a borrar nada, así que son el sitio donde suelen terminar apareciendo todas las fotos y vídeos, y en definitiva tesoros, que desaparecen de Internet.

Soy Miembro de DaPink desde hace tiempo, y hace un rato me he llevado una sorpresa increíble al ver allí 3 meses después de que todo aquello pasase, no solo el vídeo que yo conocía sino todas las fotos y más vídeos de Adelina y el estudiante. Nada más verlo he saltado a mi ordenador y me he puesto a escribir este post. Escúchame bien, esto que estas a punto de ver es algo fuera de lo normal. Si hasta hoy no sabías nada de Adelina sus fotos, pero sobre todo sus 5 vídeos, van a cambiar tu visión del mundo y del universo.

Entrar en <a href="http://greenshines.com/out/dapink">DaPink</a> y bajarte el vídeo no tiene ningún misterio, es casi como registrarte a una redsocial cualquiera, pero aquí te dejo unas mini instrucciones porque la web está en Ingles y puede que haya alguien a quien pueda ayudarle estos 3 ó 4 pasos que voy a dejar aquí.

<strong><strong>INSTRUCCIONES PARA BAJAR EL PORNO DE DAPINK</strong></strong>

<h2>Paso 1:</h2>

Lo primero que tienes que hacer es por supuesto entrar a la web.
<br><strong>enlace:</strong> <a href="http://greenshines.com/out/dapink">ENTRAR A DA PINK</a>

Al entrar en la web verás que arriba a la derecha hay un botón que dice CREATE MY FREE ACCOUNT (crear mi cuenta gratis) haz click ahí y en ningún otro sitio.

<img src="http://greenshines.com/wp-content/uploads/2016/02/Captura-de-pantalla-2017-03-13-16.57.53.png" alt="" width="670" height="210" class="" />

<h2>Paso 2:</h2>

Cuando hayas hecho click te aparecerá un formulario como este para que elijas tu nombre de usuario y contraseña. También te pide tu nombre pero no hace falta que pongas el verdadero claro.

<img style="margin-left:auto; margin-right:auto;max-width:60%; height:auto" src="http://solido.greenshines.com/Screenshot-2015-04-26-04.28.26.png">

<h2>Paso 3:</h2>

Tras este formulario aparecerá un segundo formulario para que demuestres que eres mayor de edad introduciendo tu tarjeta de crédito, esto es algo cada vez mas normal en las webs para adultos.

Fíjate que ellos mismos dicen y yo te repito porque llevo tiempo registrado que: <b>la web es gratis y no cobran absolutamente nada</b> en tu tarjeta. La web es totálmente gratis y hasta el día de hoy esa es la forma legal en Estados Unidos para comprobar en este tipo de webs que eres mayor de edad y evitar que entren menores a la página. Este es el formulario que verás.

<img style="margin-left:auto; margin-right:auto;max-width:60%; height:auto" src="http://solido.greenshines.com/Screenshot-2015-04-26-03.29.04.png">

Y esto es todo, verificas tu edad y estas dentro de una web clónica de otra que cuesta mucho dinero y que todos conocemos. Imagino que ya no te vere en dos o tres días, los vas a pasar descargando videos.
<br><br>

<a href="http://greenshines.com/out/dapink">Entra en DaPink</a> la web esta 100% aconsejada por Greenshines, es decir por mi.